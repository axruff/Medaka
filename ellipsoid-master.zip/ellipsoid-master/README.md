ellipsoid
=========

Example code for enclosing points in an elipsoid